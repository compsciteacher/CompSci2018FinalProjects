#Joshua Hinojosa
#5/20/16
#Mr.Davis
#Final Project
#v1.0
##MIT License
##Copyright (c) [2016] [Joshua Hinojosa]
##Permission is hereby granted, free of charge, to any person obtaining a copy
##of this software and associated documentation files (the "Software"), to deal
##in the Software without restriction, including without limitation the rights
##to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
##copies of the Software, and to permit persons to whom the Software is
##furnished to do so, subject to the following conditions:
##The above copyright notice and this permission notice shall be included in all
##copies or substantial portions of the Software.
##THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
##IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
##FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
##AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
##LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
##OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
##SOFTWARE.
##An exciting text-based adventure combat game where a player is challenged to
##survive through a long dungeon to escape while defeating enemies along the way.

import random, time, turtle, os

#writes the player stats to a text file when player dies

outfile=open("TSC Player Stats.txt", "w")       #creates player stats file
title=("\t" + "Player Stats" + '\n')
catg=("Class" + '\t' + "Name" + "\t" + "Attack" + "\t" +"Exp" + "  " + "LVL" + "   " + "# of Defeated Enemies" + '\n')
outfile.write(title)
outfile.write(catg)
outfile.close()

def dungeonroomnoenemy():           #creates hallway
    print('\t','''|             |X|
         |             |X|
         |             |X|                 
         |             |X|
         |             |X|
         |             |X|
         |             |X|
         |             |X|''')
    print("Name: " + hero.name,"\n",
          "HP:", hero.hp,"\n",
          "XP:", hero.exp,"\n",
          "LVL:",hero.lvl)
    print("Press 'w' to continue further into the dungeon")
    commnd=input("->")
    if commnd=="w":
        print("You continue further into the dungeon..")
        time.sleep(3)
        os.system("cls")
    else:
        print("Invalid Command!")
        time.sleep(2)
        os.system("cls")
        dungeonroomnoenemy()
        
def dungeonroomwenemy():            #creates room where player fights an enemy
    print('\t','''|             |X|
         |       %     |X|
         |             |X|                 
         |             |X|
         |             |X|
         |             |X|
         |             |X|
         |             |X|''')

#####################################################LVL UP###############################################################################
def lvl_up():           #player level up function- lets a player choose an attribute to increase once a certain amount of xp is earned
    if hero.lvl==1:
        if hero.exp>=14:
            os.startfile("Victory.ogg")
            print("Character Level Up!")
            hero.lvl=hero.lvl+1
            hero.exp=hero.exp-14
            time.sleep(3)
            print(" Name  HP  Attack",'\n',
                  hero.name,"",hero.hp,"", hero.attack)
            print("Which attribute would you like to increase?")
            print("1. Attack")
            print("2. HP")
            ui=input("->")
            if ui=="1":
                hero.attack=hero.attack+1
                print("Player attack increased by 1!")
            elif ui=="2":
                hero.maxhp=hero.maxhp+10
                print("Player max health increased by 10!")
            hero.hp=hero.maxhp
    elif hero.lvl==2:
        if hero.exp>=35:
            os.startfile("Victory.ogg")
            print("Character Level Up!")
            hero.lvl=hero.lvl+1
            hero.exp=hero.exp-32
            time.sleep(3)
            print(" Name  HP  Attack",'\n',
                  hero.name,"",hero.hp,"", hero.attack)
            print("Which attribute would you like to increase?")
            print("1. Attack")
            print("2. HP")
            ui=input("->")
            if ui=="1":
                hero.attack=hero.attack+1
                print("Player attack increased by 1!")
            elif ui=="2":
                hero.maxhp=hero.maxhp+10
                print("Player max health increased by 10!")
            hero.hp=hero.maxhp
    elif hero.lvl==3:
        if hero.exp>=50:
            os.startfile("Victory.ogg")
            print("Character Level Up!")
            hero.lvl=hero.lvl+1
            hero.exp=hero.exp-45
            time.sleep(3)
            print(" Name  HP  Attack",'\n',
                  hero.name,"",hero.hp,"", hero.attack)
            print("Which attribute would you like to increase?")
            print("1. Attack")
            print("2. HP")
            ui=input("->")
            if ui=="1":
                hero.attack=hero.attack+1
                print("Player attack increased by 1!")
            elif ui=="2":
                hero.maxhp=hero.maxhp+10
                print("Player max health increased by 10!")
            hero.hp=hero.maxhp
    elif hero.lvl==4:
        if hero.exp>=65:
            os.startfile("Victory.ogg")
            print("Character Level Up!")
            hero.lvl=hero.lvl+1
            hero.exp=hero.exp-62
            time.sleep(3)
            print(" Name  HP  Attack",'\n',
                  hero.name,"",hero.hp,"", hero.attack)
            print("Which attribute would you like to increase?")
            print("1. Attack")
            print("2. HP")
            ui=input("->")
            if ui=="1":
                hero.attack=hero.attack+1
                print("Player attack increased by 1!")
            elif ui=="2":
                hero.maxhp=hero.maxhp+10
                print("Player max health increased by 10!")
            hero.hp=hero.maxhp
##############################################HERO DEATH#################################################
def herodeath():                #when a player's health reaches 0 the player dies and the player's                
    global enemiesdefeated      #ending stats are recorded to a text file 
    print("You Died!")
    time.sleep(1)
    print("GAME OVER")
    os.startfile("Game Over.mp3")
    time.sleep(10)
    outfile=open("TSC Player Stats.txt", "a")
    cstats=[hero.pclass,hero.name,hero.attack,hero.exp, hero.lvl, enemiesdefeated]
    for a in cstats:
        outfile.write(str(a)+'\t')
    
    outfile.close()
    os.system("cls")
    infile=open("TSC Player Stats.txt", "r")
    playerstats=infile.read()
    print(playerstats)
    time.sleep(4)
    os.system("cls")
    menu()
##########################################CLASS FORMATS##################################    
class Character:                #character class format
    def __init__(self,name,pclass,maxhp,hp,attack,inventory,exp,lvl,weapon):
        self.name=name
        self.pclass=pclass
        self.maxhp=maxhp
        self.hp=hp
        self.attack=attack
        self.inventory=inventory
        self.exp=exp
        self.lvl=lvl
        self.weapon=weapon

class Enemy:                    #Enemy class format
    def __init__(self,name,hp,attack,exp,lvl):
        self.name=name
        self.hp=hp
        self.attack=attack
        self.exp=exp
        self.lvl=lvl

##################################ITEMS###############################################        
def smallhpvial():
    hero.hp=hero.hp+20
    if hero.maxhp<hero.hp:
        h=hero.hp-hero.maxhp
        hero.hp=hero.hp-h
    print("You gained 20 HP!")
    time.sleep(2)
def largehpvial():
    hero.hp=hero.hp+40
    if hero.maxhp<hero.hp:
        h=hero.hp-hero.maxhp
        hero.hp=hero.hp-h
    print("You gained 40 HP!")
    time.sleep(2)
def club():
    unequip()
    hero.attack=hero.attack+2
    hero.weapon+="Club"
def dagger():
    unequip()
    hero.attack=hero.attack+2
    hero.weapon+="Dagger"
def battleaxe():
    unequip()
    hero.attack=hero.attack+4
    hero.weapon+="Battleaxe"
def shortsword():
    unequip()
    hero.attack=hero.attack+3
    hero.weapon+="Shortsword"
def longsword():
    unequip()
    hero.attack=hero.attack+5
    hero.weapon+="Longsword"
def greatsword():
    unequip()
    hero.attack=hero.attack+8
    hero.weapon+="Greatsword"
#####################################################RANDOM ITEMS###############################    
def randomitem(): #gives user a random item 
    nums="012"
    randnum=random.choice(nums)
    if randnum=="0":
            print("You received nothing from enemy")
    elif randnum=="1":
        randnums="123456"
        randweap=random.choice(randnums)
        if randweap=="1":
            if hero.weapon=="Club":
                print("The enemy dropped an item you already have equipped")
            print("The enemy dropped a Club")
            print("Equip it?y/n")
            ui=input("->")
            if ui=="y":
                club()
            else:
                pass
            time.sleep(2)
        elif randweap=="2":
            if hero.weapon=="Dagger":
                print("The enemy dropped an item you already have equipped")
            print("The enemy dropped a Dagger")
            print("Equip it?y/n")
            ui=input("->")
            if ui=="y":
                dagger()
            else:
                pass
            time.sleep(2)
        elif randweap=="3":
            if hero.weapon=="Shortsword":
                print("The enemy dropped an item you already have equipped")
            print("The enemy dropped a Shortsword")
            print("Equip it?y/n")
            ui=input("->")
            if ui=="y":
                shortsword()
            else:
                pass
            time.sleep(2)
        elif randweap=="4":
            if hero.weapon=="Longsword":
                print("The enemy dropped an item you already have equipped")
            print("The enemy dropped a Longsword")
            print("Equip it?y/n")
            ui=input("->")
            if ui=="y":
                longsword()
            else:
                pass
            time.sleep(2)
        elif randweap=="5":
            if hero.weapon=="Battleaxe":
                print("The enemy dropped an item you already have equipped")
            print("The enemy dropped a Battleaxe")
            print("Equip it?y/n")
            ui=input("->")
            if ui=="y":
                battleaxe()
            else:
                pass
            time.sleep(2)
    
        elif randweap=="6":
            if hero.weapon=="Greatsword":
                print("The enemy dropped an item you already have equipped")
            print("The enemy dropped a Greatsword")
            print("Equip it?y/n")
            ui=input("->")
            if ui=="y":
                greatsword()
            else:
                pass
            time.sleep(2)

            
    elif randnum=="2":
        ranums="123456"
        randtemp=random.choice(ranums)
        if randtemp=="1":
            hero.inventory.append("Small Potion of Health")
            print("The enemy dropped a Small Potion of Health")
            time.sleep(2)
        elif randtemp=="2":
            hero.inventory.append("Large Potion of Health")
            print("The enemy dropped a Large Potion of Health")
            time.sleep(2)
        elif randtemp=="3":
            hero.inventory.append("Potion of Poison")
            print("The enemy dropped a Potion of Poison")
            time.sleep(2)
        elif randtemp=="4":
            hero.inventory.append("Shortbow and Arrow")
            print("The enemy dropped a Shortbow and Arrow")
            time.sleep(2)
        elif randtemp=="5":
            hero.inventory.append("Maple Longbow and Fire Arrow")
            print("The enemy dropped a Maple Longbow and Fire Arrow")
            time.sleep(2)
        elif randtemp=="6":
            hero.inventory.append("Meteor Strike")
            print("The enemy dropped a Meteor Strike")
            time.sleep(2)
####################################UNEQUIP#################################################            
def unequip():
    if hero.weapon=="Small Dagger":
        hero.attack=hero.attack-2
        hero.weapon=hero.weapon.replace("Small Dagger", "")
    elif hero.weapon=="Short staff":
        hero.attack=hero.attack-3
        hero.weapon=hero.weapon.replace("Short Staff", "")
    elif hero.weapon=="Dull Mace":
        hero.attack=hero.attack-2
        hero.weapon=hero.weapon.replace("Dull Mace", "")
    elif hero.weapon=="Club":
        hero.attack=hero.attack-2
        hero.weapon=hero.weapon.replace("Club", "")
    elif hero.weapon=="Dagger":
        hero.attack=hero.attack-2
        hero.weapon=hero.weapon.replace("Dagger", "")
    elif hero.weapon=="Battleaxe":
        hero.attack=hero.attack-4
        hero.weapon=hero.weapon.replace("Battleaxe", "")
    elif hero.weapon=="Shortsword":
        hero.attack=hero.attack-3
        hero.weapon=hero.weapon.replace("Shortsword", "")
    elif hero.weapon=="Longsword":
        hero.attack=hero.attack-5
        hero.weapon=hero.weapon.replace("Longsword", "")
    elif hero.weapon=="Greatsword":
        hero.attack=hero.attack-8
        hero.weapon=hero.weapon.replace("Greatsword", "")
    
##################################PLAYER CLASSES###################################################
class Warrior(Character):
    def __init__(self):
        super().__init__(name=input("What is your characters name?"),pclass="Warrior",attack=10,
                         maxhp=65,hp=65,inventory=['Small Potion of Health'],exp=0,lvl=1,weapon="Small Dagger")
    prof = "warrior"
    
class Juggernaut(Character):
    def __init__(self):
        super().__init__(name=input("What is your characters name?"),pclass="Juggernaut",attack=8,
                         maxhp=85,hp=85,inventory=['Small Potion of Health'],exp=0,lvl=1,weapon="Dull Mace")
    prof= "juggernaut"

class Mage(Character):
    def __init__(self):
        super().__init__(name=input("What is your characters name?"),pclass="Mage",attack=12,
                         maxhp=55,hp=55,inventory=['Small Potion of Health'],exp=0,lvl=1, weapon="Short Staff") 
    prof= "mage"

##########ENEMY CLASSES###############################################################################
class Goblin(Enemy):
    def __init__(self):
        super().__init__(name="goblin",
                         hp=18,attack=5,exp=5,lvl=1)

class Skeleton(Enemy):
    def __init__(self):
        super().__init__(name="skeleton",
                         hp=20,attack=7,exp=7,lvl=1)

class GiantSpider(Enemy):
    def __init__(self):
        super().__init__(name="giant Spider",
                         hp=24,attack=9,exp=9,lvl=1)
class Boss1(Enemy):
    def __init__(self):
        super().__init__(name="Armored Wraith",
                         hp=45,attack=12,exp=25,lvl=5)

class armoredskeleton(Enemy):
    def __init__(self):
        super().__init__(name="armored skeleton",
                         hp=28,attack=9,exp=15,lvl=5)

class troll(Enemy):
    def __init__(self):
        super().__init__(name="troll",
                         hp=35,attack=10,exp=19,lvl=5)

class orc(Enemy):
    def __init__(self):
        super().__init__(name="orc",
                         hp=34,attack=11,exp=17,lvl=5)
        
class undeadsoldier(Enemy):
    def __init__(self):
        super().__init__(name="undead soldier",
                         hp=32,attack=13,exp=22,lvl=5)

class Boss2(Enemy):
    def __init__(self):
        super().__init__(name="possessed mage",
                         hp=80,attack=18,exp=60,lvl=5)

############################################################RANDOM ENEMY BATTLE STAGE 1################################
def randenemybttl1():       #function for battling random enemies in stage 1          
    global enemiesdefeated
    os.startfile("Battle6.ogg")
    enums="123"
    enmy=random.choice(enums)
    if enmy=="1":
        enemy=Goblin() 
    elif enmy=="2": 
        enemy=Skeleton()
    elif enmy=="3": 
        enemy=GiantSpider()
    print("You see a " + enemy.name)
    time.sleep(2)
    print("He is looking for a fight!")
    time.sleep(3)
    while enemy.hp>0:
        os.system("cls")
        print("Name: " + hero.name,"\n",
          "HP:", hero.hp,"\n",
          "XP:", hero.exp,"\n",
          "LVL:",hero.lvl)
        print("Name: " + enemy.name,"\n",
          "HP:", enemy.hp,"\n",
          "XP:", enemy.exp,"\n",
          "LVL:",enemy.lvl)
        
        print("1. Attack")
        print("2. Defend")
        print("3. Inventory")
        print("What are you going to do?")
        ui=input("->")
        cdmg= random.randint(0, hero.attack)
        edmg= random.randint(0, enemy.attack)
        if ui=="1":
            if cdmg==0:
                print("You missed!")
                time.sleep(2)
            else:
                enemy.hp=enemy.hp-cdmg
                print("You did ", cdmg, " damage to enemy")
                time.sleep(3)
                if enemy.hp<=0:
                    break
                    time.sleep(1)
            if edmg==0:
                    print("Enemy missed!")
                    time.sleep(2)
            else:
                hero.hp=hero.hp-edmg
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
        elif ui=="2":
            edmg= random.randint(0, enemy.attack)
            if edmg!=0:
                edmg= edmg*.5
                edmg=int(edmg)
                hero.hp=hero.hp-edmg
                print("You blocked!")
                time.sleep(2)
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
            elif edmg==0:
                print("You blocked!")
                time.sleep(2)
                print("Enemy missed!")
                time.sleep(2)
        elif ui=="3":               #inventory function that lets a character use items in inventory
            print("Weapon Equipped: " + hero.weapon)
            print(hero.inventory)
            print("***Type out an item to use it***")
            print("Press 'r' to go back")
            ui=input("->")
            if ui=="r":
                pass
            elif ui in hero.inventory:
                if ui=="Small Potion of Health":
                    smallhpvial()
                    hero.inventory.remove(ui)
                elif ui=="Large Potion of Health":
                    largehpvial()
                    hero.inventory.remove(ui)
                elif ui=="Potion of Poison":
                    enemy.hp=enemy.hp-11
                    print("Enemy took 11 damage from poison")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Shortbow and Arrow":
                    enemy.hp=enemy.hp-17
                    print("Enemy took 17 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Maple Longbow and Fire Arrow":
                    enemy.hp=enemy.hp-27
                    print("Enemy took 27 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Meteor Strike":
                    enemy.hp=enemy.hp-50
                    print("Enemy took 50 damage from meteor")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    elif edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
            else:
                print("Item not in inventory!")
                 
        else:
            print("Invalid Command!")
    os.startfile("Yay.mp3")
    print("You killed the ", enemy.name)
    hero.exp=hero.exp+enemy.exp
    enemiesdefeated+=1
    time.sleep(3)
    print("You gained ", enemy.exp," experience!")
    lvl_up()
    time.sleep(3)
    randomitem()
    time.sleep(3)
    os.system("cls")
    os.startfile("Dungeon Theme.ogg")
##########################################################RANDOM ENEMY BATTLE STAGE 2######################
def randenemybttl2():           #function for battling random enemies in stage 2
    global enemiesdefeated
    os.startfile("Battle6.ogg")
    enums="1234"
    enmy=random.choice(enums)
    if enmy=="1":
        enemy=armoredskeleton() 
    elif enmy=="2": 
        enemy=troll()
    elif enmy=="3": 
        enemy=orc()
    elif enmy=="4": 
        enemy=undeadsoldier()
        
    print("You see a " + enemy.name)
    time.sleep(2)
    print("He is looking for a fight!")
    time.sleep(3)
    while enemy.hp>0:
        os.system("cls")
        print("Name: " + hero.name,"\n",
          "HP:", hero.hp,"\n",
          "XP:", hero.exp,"\n",
          "LVL:",hero.lvl)
        print("Name: " + enemy.name,"\n",
          "HP:", enemy.hp,"\n",
          "XP:", enemy.exp,"\n",
          "LVL:",enemy.lvl)
        
        print("1. Attack")
        print("2. Defend")
        print("3. Inventory")
        print("What are you going to do?")
        ui=input("->")
        cdmg= random.randint(0, hero.attack)
        edmg= random.randint(0, enemy.attack)
        if ui=="1":
            if cdmg==0:
                print("You missed!")
                time.sleep(2)
            else:
                enemy.hp=enemy.hp-cdmg
                print("You did ", cdmg, " damage to enemy")
                time.sleep(3)
                if enemy.hp<=0:
                    break
                    time.sleep(1)
            if edmg==0:
                    print("Enemy missed!")
                    time.sleep(2)
            else:
                hero.hp=hero.hp-edmg
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
        elif ui=="2":
            edmg= random.randint(0, enemy.attack)
            if edmg!=0:
                edmg= edmg*.5
                edmg=int(edmg)
                hero.hp=hero.hp-edmg
                print("You blocked!")
                time.sleep(2)
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
            elif edmg==0:
                print("You blocked!")
                time.sleep(2)
                print("Enemy missed!")
                time.sleep(2)
        elif ui=="3":               #inventory function that lets a character use items in inventory
            print("Weapon Equipped: " + hero.weapon)
            print(hero.inventory)
            print("***Type out an item to use it***")
            print("Press 'r' to go back")
            ui=input("->")
            if ui=="r":
                pass
            elif ui in hero.inventory:
                if ui=="Small Potion of Health":
                    smallhpvial()
                    hero.inventory.remove(ui)
                elif ui=="Large Potion of Health":
                    largehpvial()
                    hero.inventory.remove(ui)
                elif ui=="Potion of Poison":
                    enemy.hp=enemy.hp-11
                    print("Enemy took 11 damage from poison")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Shortbow and Arrow":
                    enemy.hp=enemy.hp-17
                    print("Enemy took 17 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Maple Longbow and Fire Arrow":
                    enemy.hp=enemy.hp-27
                    print("Enemy took 27 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Meteor Strike":
                    enemy.hp=enemy.hp-50
                    print("Enemy took 50 damage from meteor")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    elif edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
            else:
                print("Item not in inventory!")
                 
        else:
            print("Invalid Command!")
    os.startfile("Yay.mp3")
    print("You killed the ", enemy.name)
    hero.exp=hero.exp+enemy.exp
    enemiesdefeated+=1
    time.sleep(3)
    print("You gained ", enemy.exp," experience!")
    lvl_up()
    time.sleep(3)
    randomitem()
    time.sleep(3)
    os.system("cls")
    os.startfile("Dungeon Theme.ogg")

#######################################################BOSS 1##########################################    
def boss1(): #function for boss 1 fight
    global enemiesdefeated
    enemy=Boss1()
    os.startfile("United We Stand - Divided We Fall.mp3")
    print("You see a bright light up ahead. As you get closer you see a dark figure")
    print("and find out that it is not a way out of the dungeon.")
    time.sleep(6)
    dungeonroomwenemy()
    print("It is an " + enemy.name + "!")
    while enemy.hp>0:
        os.system("cls")
        print("Name: " + hero.name,"\n",
          "HP:", hero.hp,"\n",
          "XP:", hero.exp,"\n",
          "LVL:",hero.lvl)
        print("Name: " + enemy.name,"\n",
          "HP:", enemy.hp,"\n",
          "XP:", enemy.exp,"\n",
          "LVL:",enemy.lvl)
        
        print("1. Attack")
        print("2. Defend")
        print("3. Inventory")
        print("What are you going to do?")
        ui=input("->")
        cdmg= random.randint(0, hero.attack)
        edmg= random.randint(0, enemy.attack)
        if ui=="1":
            if cdmg==0:
                print("You missed!")
                time.sleep(2)
            else:
                enemy.hp=enemy.hp-cdmg
                print("You did ", cdmg, " damage to enemy")
                time.sleep(3)
                if enemy.hp<=0:
                    break
                    time.sleep(1)
            if edmg==0:
                    print("Enemy missed!")
                    time.sleep(2)
            else:
                hero.hp=hero.hp-edmg
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
        elif ui=="2":
            edmg= random.randint(0, enemy.attack)
            if edmg!=0:
                edmg= edmg*.5
                edmg=int(edmg)
                hero.hp=hero.hp-edmg
                print("You blocked!")
                time.sleep(2)
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
            elif edmg==0:
                print("You blocked!")
                time.sleep(2)
                print("Enemy missed!")
                time.sleep(2)
        elif ui=="3":               #inventory function that lets a character use items in inventory
            print("Weapon Equipped: " + hero.weapon)
            print(hero.inventory)
            print("***Type out an item to use it***")
            print("Press 'r' to go back")
            ui=input("->")
            if ui=="r":
                pass
            elif ui in hero.inventory:
                if ui=="Small Potion of Health":
                    smallhpvial()
                    hero.inventory.remove(ui)
                elif ui=="Large Potion of Health":
                    largehpvial()
                    hero.inventory.remove(ui)
                elif ui=="Potion of Poison":
                    enemy.hp=enemy.hp-11
                    print("Enemy took 11 damage from poison")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Shortbow and Arrow":
                    enemy.hp=enemy.hp-17
                    print("Enemy took 17 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Maple Longbow and Fire Arrow":
                    enemy.hp=enemy.hp-27
                    print("Enemy took 27 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Meteor Strike":
                    enemy.hp=enemy.hp-50
                    print("Enemy took 50 damage from meteor")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    elif edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
            else:
                print("Item not in inventory!")
                 
        else:
            print("Invalid Command!")
            
    os.startfile("Victory.ogg")                       
    print("You killed the ", enemy.name)
    hero.exp=hero.exp+enemy.exp
    enemiesdefeated+=1
    time.sleep(3)
    print("Stage 1 Completed!")
    time.sleep(2)
    print("You gained", enemy.exp,"experience!")
    lvl_up()
    time.sleep(3)
    randomitem()
    time.sleep(3)
    os.system("cls")
    os.startfile("Dungeon Theme.ogg")

###############################################FINAL BOSS######################################
def finalboss():
    global enemiesdefeated
    enemy=Boss2()
    print("You see a bright light up ahead. As you get closer you see a dark figure")
    print("You see a door behind him. There is a key hangin on the wallbehind the dark")
    print("figure. It must be the way out.")
    time.sleep(7)
    os.startfile("Battle8.ogg")
    dungeonroomwenemy()
    print("It is an " + enemy.name + "!")
    while enemy.hp>0:
        os.system("cls")
        print("Name: " + hero.name,"\n",
          "HP:", hero.hp,"\n",
          "XP:", hero.exp,"\n",
          "LVL:",hero.lvl)
        print("Name: " + enemy.name,"\n",
          "HP:", enemy.hp,"\n",
          "XP:", enemy.exp,"\n",
          "LVL:",enemy.lvl)
        
        print("1. Attack")
        print("2. Defend")
        print("3. Inventory")
        print("What are you going to do?")
        ui=input("->")
        cdmg= random.randint(0, hero.attack)
        edmg= random.randint(0, enemy.attack)
        if ui=="1":
            if cdmg==0:
                print("You missed!")
                time.sleep(2)
            else:
                enemy.hp=enemy.hp-cdmg
                print("You did ", cdmg, " damage to enemy")
                time.sleep(3)
                if enemy.hp<=0:
                    break
                    time.sleep(1)
            if edmg==0:
                    print("Enemy missed!")
                    time.sleep(2)
            else:
                hero.hp=hero.hp-edmg
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
        elif ui=="2":
            edmg= random.randint(0, enemy.attack)
            if edmg!=0:
                edmg= edmg*.5
                edmg=int(edmg)
                hero.hp=hero.hp-edmg
                print("You blocked!")
                time.sleep(2)
                print("Enemy did ", edmg, " damage to you")
                time.sleep(3)
                if hero.hp<=0:
                    herodeath()
            elif edmg==0:
                print("You blocked!")
                time.sleep(2)
                print("Enemy missed!")
                time.sleep(2)
        elif ui=="3":               #inventory function that lets a character use items in inventory
            print("Weapon Equipped: " + hero.weapon)
            print(hero.inventory)
            print("***Type out an item to use it***")
            print("Press 'r' to go back")
            ui=input("->")
            if ui=="r":
                pass
            elif ui in hero.inventory:
                if ui=="Small Potion of Health":
                    smallhpvial()
                    hero.inventory.remove(ui)
                elif ui=="Large Potion of Health":
                    largehpvial()
                    hero.inventory.remove(ui)
                elif ui=="Potion of Poison":
                    enemy.hp=enemy.hp-11
                    print("Enemy took 11 damage from poison")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Shortbow and Arrow":
                    enemy.hp=enemy.hp-17
                    print("Enemy took 17 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Maple Longbow and Fire Arrow":
                    enemy.hp=enemy.hp-27
                    print("Enemy took 27 damage from arrow")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
                elif ui=="Meteor Strike":
                    enemy.hp=enemy.hp-50
                    print("Enemy took 50 damage from meteor")
                    time.sleep(3)
                    hero.inventory.remove(ui)
                    edmg= random.randint(0, enemy.attack)
                    if enemy.hp<=0:
                        break
                        time.sleep(1)
                    elif edmg==0:
                        print("Enemy missed!")
                        time.sleep(2)
                    else:
                        hero.hp=hero.hp-edmg
                        print("Enemy did ", edmg, " damage to you")
                        time.sleep(3)
                        if hero.hp<=0:
                            herodeath()
            else:
                print("Item not in inventory!")
                 
        else:
            print("Invalid Command!")
            
    os.startfile("Gamewin.ogg")                       
    print("You killed the ", enemy.name)
    hero.exp=hero.exp+enemy.exp
    enemiesdefeated+=1
    time.sleep(2)
    f=False
    while f is False:
        print("Press 'g' to grab the keys off the wall.")
        userinp=input("->")
        if userinp=="g":
            f=True
            print("You unlock the dungeon door and escape the dungeon.")
        else:
            print("Invalid command!")
    os.startfile("Gamewin.ogg")
    print("Final Stage Completed!")
    time.sleep(7)
    print("You gained", enemy.exp,"experience!")
    lvl_up()
    print("GAME COMPLETED!")
    time.sleep(2)
    outfile=open("TSC Player Stats.txt", "a")
    cstats=[hero.pclass,hero.name,hero.attack,hero.exp, hero.lvl, enemiesdefeated]
    for a in cstats:
        outfile.write(str(a)+'\t')

    outfile.close()
    time.sleep(3)
    os.system("cls")
    infile=open("TSC Player Stats.txt", "r")
    playerstats=infile.read()
    print(playerstats)
    time.sleep(8)
    os.system("cls")
    menu()
    
def playerclass():                  #lets the player select a character class
    try:
        print("Choose your class:",'\n',
              " press 'w' for Warrior",'\n',
              " press 'j' for Juggernaut",'\n',
              " press 'm' for Mage")
        pclass=input("->")
        if pclass.lower()=="w":
            Prof = Warrior()
            return Prof
        elif pclass.lower()=="j":
            Prof = Juggernaut()
            return Prof
        elif pclass.lower()== "m":
            Prof = Mage()
            return Prof
        else:
            print("ERROR! NOT a class choice!")
            playerclass()
    except KeyboardInterrupt:
        print("INVALID COMMAND!")
        os.system("cls")
        playerclass()
##################################################STAGE 1###################################    
def stage1():            #function for stage 1           
    global heroexp
    print("You walk through the wooden door.")
    heroexp=hero.exp
    time.sleep(3)
    dungeonroomwenemy()
    randenemybttl1()
    dungeonroomnoenemy()
    randenemybttl1()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    randenemybttl1()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    boss1()
    finalstage()

#####################################################FINAL STAGE################################
def finalstage():
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    randenemybttl2()
    dungeonroomnoenemy()
    randenemybttl2()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    randenemybttl2()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    randenemybttl2()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    randenemybttl2()
    dungeonroomnoenemy()
    dungeonroomnoenemy()
    finalboss()

def choosehero():    #lets player choose character class           
    global enemiesdefeated,hero
    enemiesdefeated=0
    hero=playerclass()
    os.system('cls')
    time.sleep(1)
    print("Loading...")
    time.sleep(3)
    os.system('cls')
    os.startfile("Explosion.ogg")
    time.sleep(2)
    print("There was an explosion from a cannon and you suddenly wake up in an underground dungeon.")
    time.sleep(3)
    startgame()
    os.startfile("Dungeon Theme.ogg")
    
def startgame(): #starts the game
    try:
        global hero 
        print('\t','''|      __     |X|
         |     | .|    |X|
         |     |  |    |X|                 
         |             |X|
         |             |X|
         |             |X|
         |             |X|
         |             |X|''')
        time.sleep(2) 
        print("Name: " + hero.name,"\n",
              "HP:", hero.hp,"\n",
              "XP:", hero.exp,"\n",
              "LVL:",hero.lvl)
        
        print("Press 'e' to open door")
        ui=input("->")      #puts you back at the menu for right now
        if ui=='e':
            os.system("cls")
            stage1()
        else:
            print("Invalid Command!")
            time.sleep(2)
            os.system('cls')
            startgame()
    except KeyboardInterrupt:
        print("INVALID COMMAND!")
        os.system("cls")
        startgame()
def menu():#menu function
    try:
        os.startfile("Enspiron.mp3")
        print('\t', "The Soul of Chyra")
        print("<<===============================>>")
        print("1. START GAME ->")
        print("2. QUIT")
        ui=input("->")
        if ui=="1":
            os.system("cls")
            choosehero()
        if ui =="2":
            quit()
        else:
            print("Invalid choice!")
            os.system("cls")
            menu()
    except KeyboardInterrupt:
        print("INVALID COMMAND!")
        os.system("cls")
        menu()
        
def intro():        #title screen intro function
    print("In a world...")
    time.sleep(2)
    print("..where one soul is left to die after the The Great War"
    " has destroyed the city  of Chyra.")
    time.sleep(4)
    wn = turtle.Screen()
    wn.bgcolor("black")
    ttl=turtle.Turtle()
    ttl.color("red")
    ttl.write("The Soul of Chyra", move=False, align="center", font=("Times New Roman", 48, "normal"))
    os.startfile("Intro theme.ogg")
    ttl.color("gray")
    ttl.write("[click to continue]",move=False, align="center", font=("Times New Roman", 12, "normal"))
    wn.exitonclick()
    os.system("cls")
    menu()
intro()   
